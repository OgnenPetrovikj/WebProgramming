package mk.finki.ukim.mk.lab.repository.inmemory;

import org.springframework.stereotype.Repository;

@Repository
public class InMemoryArtistRepository { }
