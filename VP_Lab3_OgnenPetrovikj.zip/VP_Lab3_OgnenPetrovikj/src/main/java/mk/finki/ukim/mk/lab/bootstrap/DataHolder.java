package mk.finki.ukim.mk.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.finki.ukim.mk.lab.model.*;
import mk.finki.ukim.mk.lab.repository.jpa.AlbumRepository;
import mk.finki.ukim.mk.lab.repository.jpa.ArtistRepository;
import mk.finki.ukim.mk.lab.repository.jpa.SongRepository;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Artist> artists;
    public static List<Song> songs;
    public static List<Album> albums;

    private final SongRepository songRepository;
    private final AlbumRepository albumRepository;
    private final ArtistRepository artistRepository;

    public DataHolder(SongRepository songRepository, AlbumRepository albumRepository, ArtistRepository artistRepository) {
        this.songRepository = songRepository;
        this.albumRepository = albumRepository;
        this.artistRepository = artistRepository;
    }

    @PostConstruct
    public void init() {
        artists = new ArrayList<>();
        artists.add(new Artist("Travis", "Scott", "Rap"));
        artists.add(new Artist("Jimi", "Hendrix", "Jazz"));
        artists.add(new Artist("Mozzart", " ", "Classical"));
        artists.add(new Artist("Ozzy", "Ozbourne", "Heavy Metal"));
        artists.add(new Artist("Katy", "Perry", "Pop"));

        if (this.artistRepository.count() == 0) {
            this.artistRepository.saveAll(artists);
        }

        albums = new ArrayList<>();
        albums.add(new Album("2014FHD", "Rap", 2014));
        albums.add(new Album("DAMN", "Rap", 2017));
        albums.add(new Album("Dark Horse", "Pop", 2012));
        albums.add(new Album("1999", "Rap", 2012));
        albums.add(new Album("Ready to die", "Rap", 1994));

        if (this.albumRepository.count() == 0) {
            this.albumRepository.saveAll(albums);
        }

        songs = new ArrayList<>();
        songs.add(new Song("1","Dear mama", "Rap", 1996));
        songs.add(new Song("2","Espresso", "Pop", 2024));
        songs.add(new Song("3","Goosebumps", "Rap", 2015));
        songs.add(new Song("4","Hymn for the weekend", "Pop rock", 2016));
        songs.add(new Song("5","The hills", "RnB", 2014));
        for(int i =0;i<songs.size();i++){
            songs.get(i).setAlbum(albums.get(i));
        }
        if (this.songRepository.count() == 0) {
            this.songRepository.saveAll(songs);
        }

    }
}
